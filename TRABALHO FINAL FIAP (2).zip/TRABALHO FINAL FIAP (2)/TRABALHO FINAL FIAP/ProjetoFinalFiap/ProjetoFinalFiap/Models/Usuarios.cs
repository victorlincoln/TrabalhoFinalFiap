﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoFinalFiap.Models
{
    public class Usuarios
    {
        
        public string Nome { get; set; }

        
        public string Email { get; set; }

        

        public string Senha { get; set; }

        
        public int Cpf { get; set; }

        
        public string Genero { get; set; }

        
        public float Peso { get; set; }


        
        public float Altura { get; set; }

        
        public string EstadoCivil { get; set; }

        

        public string TpSanguineo { get; set; }

        
        public int DataNascimento { get; set; }


    }
}
